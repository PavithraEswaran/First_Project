package com.demo.Dao;
import org.springframework.jdbc.core.BeanPropertyRowMapper;    
import org.springframework.jdbc.core.JdbcTemplate;    
import org.springframework.jdbc.core.RowMapper;

import com.demo.Entity.Employee;    
public class EmployeeDao {

	JdbcTemplate template;
	public void setTemplate(JdbcTemplate template) {    
	    this.template = template;    
	}    
	
	public int insert(Employee e)
	{
		String sql="insert into employee (?,?,?,?,?,?)";
		return template.update(sql,e.getEmp_id(),e.getEmp_name(),e.getEmp_Designation(),e.getEmp_Location(),e.getUser_name(),e.getPassword());
	}
}
