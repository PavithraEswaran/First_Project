package com.demo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.Dao.EmployeeDao;

@Controller
public class EmployeeController {
  EmployeeDao emp;
	@RequestMapping("/submitForm")
	
	public void call()
	{
		emp.insert(e);
	}
	
}
