package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@RequestMapping("/home")
	public String display()
	{
		return "hello";
	}
	@RequestMapping("/bye")
	public String display1()
	{
		return "bye";
	}
}
