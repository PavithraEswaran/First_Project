package com.iocdi.sample.Autowired_Samples;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
 

/* autowire="byName" : 
     Autowiring using property name. If a bean found with same name as the property of 
     other bean, this bean will be wired into other beans property*/

/*   autowire="byType" : 
	 If a bean found with same type as the type of property of other 
	 bean, this bean will be wired into other beans property*/
	 
/*   autowire="constructor" : 
     If a bean found with same type as the constructor argument of other
     bean, this bean will be wired into other bean constructor*/

/*     autowire="no" :
    	 No Autowiring. Same as explicitly specifying bean 
    	 using ‘ref’ attribute*/

public class AppMain {
    public static void main(String args[]){
        AbstractApplicationContext context = new ClassPathXmlApplicationContext("app-config.xml");
 
        System.out.println();
        //autowire=byName 
        Application application = (Application)context.getBean("application");
        System.out.println("Application Details : "+application);
        System.out.println();
        
       //autowire=byType
        Employee employee = (Employee)context.getBean("employee");
        System.out.println("Employee Details : "+employee);
        System.out.println();
        
       //autowire=constructor
        Performer performer = (Performer)context.getBean("performer");
        System.out.println("Performer Details : "+performer);
        System.out.println();
        
       //autowire=default
        Driver driver = (Driver)context.getBean("driver");
        System.out.println("Driver Details : "+driver);
        System.out.println();
    }
}