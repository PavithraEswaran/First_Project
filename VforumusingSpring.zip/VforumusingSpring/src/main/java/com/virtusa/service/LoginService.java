package com.virtusa.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.virtusa.DAO.LoginDAO;
import com.virtusa.Entity.Login;

public class LoginService {
	
	@Autowired
	LoginDAO dao;
	public Login validateUser(Login login)
	{
		
		return dao.validateUser(login);
	}
}
