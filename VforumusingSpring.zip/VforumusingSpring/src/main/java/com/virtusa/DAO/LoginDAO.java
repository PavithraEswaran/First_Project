package com.virtusa.DAO;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.virtusa.Entity.Login;

public class LoginDAO {
	
	  @Autowired
	  DataSource datasource;

	  @Autowired
	  JdbcTemplate jdbcTemplate;

	 

	  public Login validateUser(Login login) {

	    String sql = "select emp_id,password from employee where emp_id='" + login.getEmpid()+ "' and password='" + login.getPassword()
	        + "'";

	    List<Login> users = jdbcTemplate.query(sql, new UserMapper());

	    return users.size() > 0 ? users.get(0) : null;
	  }

	}

	class UserMapper implements RowMapper<Login> {

	  public Login mapRow(ResultSet rs, int arg1) throws SQLException {
	    Login login = new Login();
	    login.setEmpid(rs.getInt("emp_id"));
	    login.setPassword(rs.getString("password"));
	    

	    return login;
	  }
	}

